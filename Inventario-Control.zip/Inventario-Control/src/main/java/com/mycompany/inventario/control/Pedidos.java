
package com.mycompany.inventario.control;

import java.awt.HeadlessException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public final class Pedidos extends javax.swing.JPanel {

    public static int codigoDeTienda;
    public static Double pagadoUno;
    public static Double totUno;
    public static Double pagadoDos;
    public static Double totDos;
    public static Double restanteAPagar = 0.0;
    public static String barcode_c = "0";
    public static String clieId = "0";
    public static String clie_ID;
    public static boolean binario = false;
    private static String nombre_cliente;
    private static String indice;
    private static double comparacion = 0;
    private static double cantidadRequerida = 0;

    public static double getCantidadRequerida() {
        return cantidadRequerida;
    }

    public static void setCantidadRequerida(double cantidadRequerida) {
        Pedidos.cantidadRequerida = cantidadRequerida;
    }

    public static double getComparacion() {
        return comparacion;
    }

    public static void setComparacion(double comparacion) {
        Pedidos.comparacion = comparacion;
    }

    public Pedidos() {
        initComponents();
        tablaEnPantalla();

    }

    public void tablaEnPantalla() {//incio método

        try {
            DefaultTableModel dtm = (DefaultTableModel) tablaDatosJ.getModel();
            dtm.setRowCount(0);

            Statement s = dB.miConexion().createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM tabla_productos ORDER BY codigo DESC");

            while (rs.next()) {//inicio del bucle while 
                Vector v = new Vector();
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                v.add(rs.getString(6));
                v.add(rs.getString(7));
                v.add(rs.getString(8));
                v.add(rs.getString(9));

                dtm.addRow(v);
            }//fin bucle while
        } catch (SQLException e) {
            System.out.println(e);
        }

    }//fin metodo

    public void cargarDatos() {

        try {

            Statement s = dB.miConexion().createStatement();

            ResultSet rs = s.executeQuery("SELECT * FROM tabla_productos WHERE tiendaid = '" + codigoDeTienda + "'");
            Vector v = new Vector();

            while (rs.next()) {
                v.add(rs.getString("nombre"));

                DefaultComboBoxModel dcbm = new DefaultComboBoxModel(v);
                comboProductos.setModel(dcbm);

            }

        } catch (SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "No existe la tienda ingresada");
        }

        try {

            Statement s = dB.miConexion().createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM extra WHERE exid =1");

            if (rs.next()) {

                numeroDeVenta.setText(rs.getString("val"));

            }

        } catch (SQLException e) {
        }

        int i = Integer.valueOf(numeroDeVenta.getText());
        i++;
        numeroDeVenta.setText(String.valueOf(i));

    }

    public void calculosPrecioProductos() {

        Double cantidad = Double.valueOf(cajaCantidadesProducto.getText());

        System.out.println("SE CUMPLE ESTO !!!!");
        verificacion();
        Double precio = Double.valueOf(precioUnitario.getText());
        Double tot;

        tot = cantidad * precio;

        precioT.setText(String.valueOf(tot));

    }

    public void verificacion() {
        System.out.println("ENTRO AL METODO!!!!");
        cantidadRequerida = Double.valueOf(cajaCantidadesProducto.getText());
        String id = comboProductos.getSelectedItem().toString();
        try {

            Statement sDos = dB.miConexion().createStatement();
            ResultSet rsDos = sDos.executeQuery("SELECT codigo FROM tabla_productos  WHERE nombre ='" + id + "'  ");

            if (rsDos.next()) {
                String val = rsDos.getObject(1).toString();
                indice = val;
            }

            Statement s = dB.miConexion().createStatement();
            ResultSet rs = s.executeQuery("SELECT cantidad FROM tabla_productos WHERE codigo ='" + indice + "' ");
            if (rs.next()) {
                int val = Integer.parseInt(rs.getObject(1).toString());
                comparacion = (double) val;
                System.out.println(val);
            }

        } catch (SQLException e) {

            System.out.println(e);
        }

    }

    public void carritoTotal() {

        int numFila = tablaFacturacion.getRowCount();

        double total = 0;

        for (int i = 0; i < numFila; i++) {

            double valor = Double.valueOf(tablaFacturacion.getValueAt(i, 5).toString());
            total += valor;
        }
        pagoTotal.setText(Double.toString(total));

        int numeroDeFilas = tablaFacturacion.getRowCount();

        double totales = 0;

        for (int i = 0; i < numeroDeFilas; i++) {

            double valores = Double.valueOf(tablaFacturacion.getValueAt(i, 3).toString());
            totales += valores;
        }
        cantidadTotal.setText(Double.toString(totales));

    }

    public void tot() {

        if (binario == true) {
            pagadoUno = Double.valueOf(pagoCredito.getText());
            totUno = Double.valueOf(pagoTotal.getText());
            System.out.println(pagadoUno);

            restanteAPagar = pagadoUno - totUno;

            saldoRestante.setText(String.valueOf(restanteAPagar));
        }
        if (binario == false) {

            pagadoDos = Double.valueOf(pagoEnEfectivo.getText());
            totDos = Double.valueOf(pagoTotal.getText());

            restanteAPagar = pagadoDos - totDos;

            saldoRestante.setText(String.valueOf(restanteAPagar));

        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        botonFacturar1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        cajaTiendaSolicitud = new javax.swing.JTextField();
        iniciarCargaDeCombo = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        cajaTiendaEntrega = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        pagoEnEfectivo = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        pagoCredito = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        cajaNombreCliente = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        cajaFechaRealizada = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        botonFacturar = new javax.swing.JButton();
        saldoRestante = new javax.swing.JLabel();
        pagoTotal = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        cantidadTotal = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        comboProductos = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        cajaCantidadesProducto = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        codigoP = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        precioT = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        precioUnitario = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        existenciasTotales = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        numeroDeVenta = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablaDatosJ = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaFacturacion = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        botonAniadirAlPedido = new javax.swing.JButton();
        botonQuitarDelPedido = new javax.swing.JButton();
        botonQuitarTodo = new javax.swing.JButton();

        botonFacturar1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        botonFacturar1.setText("Facturar");
        botonFacturar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonFacturar1ActionPerformed(evt);
            }
        });

        setPreferredSize(new java.awt.Dimension(1179, 659));

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        cajaTiendaSolicitud.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        cajaTiendaSolicitud.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cajaTiendaSolicitudKeyReleased(evt);
            }
        });

        iniciarCargaDeCombo.setText("Cargar Inventario");
        iniciarCargaDeCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iniciarCargaDeComboActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel15.setText("TIENDA A LA QUE SE SOLICITA");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel15)
                .addGap(18, 18, 18)
                .addComponent(cajaTiendaSolicitud, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52)
                .addComponent(iniciarCargaDeCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(123, 123, 123))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(iniciarCargaDeCombo)
                    .addComponent(cajaTiendaSolicitud, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15))
                .addContainerGap())
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("TIENDA A LA QUE SE ENVÍA : ");

        cajaTiendaEntrega.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        cajaTiendaEntrega.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cajaTiendaEntregaKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cajaTiendaEntrega, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cajaTiendaEntrega, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0))
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("Efectivo:");

        pagoEnEfectivo.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        pagoEnEfectivo.setText("0");
        pagoEnEfectivo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                pagoEnEfectivoKeyReleased(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel13.setText("Credito");

        pagoCredito.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        pagoCredito.setText("0");
        pagoCredito.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                pagoCreditoKeyReleased(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setText("DETALLES DEL PEDIDO:");

        cajaNombreCliente.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        cajaNombreCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaNombreClienteActionPerformed(evt);
            }
        });
        cajaNombreCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cajaNombreClienteKeyReleased(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel17.setText("Nombre del Cliente: ");

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel18.setText("Fecha: ");

        cajaFechaRealizada.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        cajaFechaRealizada.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cajaFechaRealizadaKeyReleased(evt);
            }
        });

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        botonFacturar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        botonFacturar.setText("Realizar Pedido");
        botonFacturar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonFacturarActionPerformed(evt);
            }
        });

        saldoRestante.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        saldoRestante.setText("00.00");
        saldoRestante.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        pagoTotal.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        pagoTotal.setText("00.00");
        pagoTotal.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Balance: ");

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel10.setText("Cantidad Total:");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Cantidad total de articulos: ");

        cantidadTotal.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cantidadTotal.setText("00");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(cantidadTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(pagoTotal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(saldoRestante, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(botonFacturar, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(cantidadTotal)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pagoTotal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(saldoRestante, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(botonFacturar, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(18, 18, 18)
                                .addComponent(pagoEnEfectivo, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addGap(31, 31, 31)
                                .addComponent(pagoCredito, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(76, 76, 76)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17)
                    .addComponent(jLabel18))
                .addGap(31, 31, 31)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cajaNombreCliente)
                    .addComponent(cajaFechaRealizada, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cajaNombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(pagoEnEfectivo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(pagoCredito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cajaFechaRealizada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jPanel10.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        comboProductos.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        comboProductos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Despliegue" }));
        comboProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboProductosActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("Producto :");

        cajaCantidadesProducto.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        cajaCantidadesProducto.setText("0");
        cajaCantidadesProducto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cajaCantidadesProductoKeyReleased(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("Cantidad:");

        codigoP.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        codigoP.setText("0");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("Precio Total:");

        precioT.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        precioT.setText("00.00");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Precio Unitario:");

        precioUnitario.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        precioUnitario.setText("00.00");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setText("Codigo Prod:");

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel12.setText("Existencias:");

        existenciasTotales.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        existenciasTotales.setText("00.00");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(cajaCantidadesProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(comboProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(precioUnitario, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(existenciasTotales, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(precioT, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(67, 67, 67)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(codigoP, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(25, 25, 25))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel12))
                        .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cajaCantidadesProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(comboProductos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 5, Short.MAX_VALUE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(precioUnitario)
                            .addComponent(existenciasTotales)
                            .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(precioT)
                                .addComponent(codigoP)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        jPanel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel16.setText("GESTIÓN DE PEDIDOS: ");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("FACTURA:");

        numeroDeVenta.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        numeroDeVenta.setText("01");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(53, 53, 53)
                .addComponent(numeroDeVenta)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(jLabel2)
                    .addComponent(numeroDeVenta))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        tablaDatosJ.setFont(new java.awt.Font("DejaVu Sans", 0, 8)); // NOI18N
        tablaDatosJ.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Fabricante", "Codigo", "Cantidad", "Precio", "TiendaID", "Descripcion", "Garantia"
            }
        ));
        tablaDatosJ.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaDatosJMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tablaDatosJ);

        tablaFacturacion.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        tablaFacturacion.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Factura", "Nombre", "Codigo", "Cantidad", "Precio Unitario", "Precio Total"
            }
        ));
        tablaFacturacion.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tablaFacturacionFocusGained(evt);
            }
        });
        jScrollPane1.setViewportView(tablaFacturacion);

        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        botonAniadirAlPedido.setText("Añadir al pedido");
        botonAniadirAlPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAniadirAlPedidoActionPerformed(evt);
            }
        });

        botonQuitarDelPedido.setText("Quitar");
        botonQuitarDelPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonQuitarDelPedidoActionPerformed(evt);
            }
        });

        botonQuitarTodo.setText("Quitar Todo");
        botonQuitarTodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonQuitarTodoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botonAniadirAlPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonQuitarDelPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonQuitarTodo, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(botonAniadirAlPedido)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonQuitarDelPedido)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonQuitarTodo)
                .addGap(0, 0, 0))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 730, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 668, Short.MAX_VALUE))
                        .addGap(29, 29, 29)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 961, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void botonAniadirAlPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAniadirAlPedidoActionPerformed
        if (getCantidadRequerida() > getComparacion()) {
            JOptionPane.showMessageDialog(null, "PRODUCTO EN INVENTARIO INSUFICIENTE");
        } else if (getCantidadRequerida() <= getComparacion()) {
            DefaultTableModel dtm = (DefaultTableModel) tablaFacturacion.getModel();

            Vector v = new Vector();

            v.add(numeroDeVenta.getText());
            v.add(comboProductos.getSelectedItem().toString());
            v.add(codigoP.getText());
            v.add(cajaCantidadesProducto.getText());
            v.add(precioUnitario.getText());
            v.add(precioT.getText());
            dtm.addRow(v);

            carritoTotal();
            tot();
        }


    }//GEN-LAST:event_botonAniadirAlPedidoActionPerformed

    private void botonQuitarDelPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonQuitarDelPedidoActionPerformed

        try {

            DefaultTableModel dtm = (DefaultTableModel) tablaFacturacion.getModel();
            int fl = tablaFacturacion.getSelectedRow();

            dtm.removeRow(fl);

        } catch (Exception e) {
        }

        carritoTotal();
        tot();


    }//GEN-LAST:event_botonQuitarDelPedidoActionPerformed

    private void botonQuitarTodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonQuitarTodoActionPerformed

        DefaultTableModel dtm = (DefaultTableModel) tablaFacturacion.getModel();
        dtm.setRowCount(0);

        carritoTotal();
        tot();
    }//GEN-LAST:event_botonQuitarTodoActionPerformed

    private void pagoEnEfectivoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pagoEnEfectivoKeyReleased
        binario = false;
        tot();


    }//GEN-LAST:event_pagoEnEfectivoKeyReleased

    private void botonFacturarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonFacturarActionPerformed

        try {

            DefaultTableModel dtm = (DefaultTableModel) tablaFacturacion.getModel();
            int rc = dtm.getRowCount();

            for (int i = 0; i < rc; i++) {

                String numero_factura = dtm.getValueAt(i, 0).toString();
                Double pagoTot = Double.valueOf(pagoTotal.getText());
                String codigoProd = dtm.getValueAt(i, 2).toString();
                String cantidad = dtm.getValueAt(i, 3).toString();
                String anticipo = dtm.getValueAt(i, 5).toString();
                String tiendaU = cajaTiendaSolicitud.getText();
                String tiendaD = cajaTiendaEntrega.getText();
                String fecha = cajaFechaRealizada.getText();
                String cliente = cajaNombreCliente.getText();
                String credito = pagoCredito.getText();

                System.out.println(nombre_cliente);
                Statement s = dB.miConexion().createStatement();
                s.executeUpdate(" INSERT INTO tabla_pedidos ( codigo_pedido, tienda_uno,tienda_dos, fecha, cliente, articulo, cantidad, total, atnicipo) VALUES ('" + numero_factura + "','" + tiendaU + "','" + tiendaD + "','" + fecha + "','" + cliente + "','" + codigoProd + "', ,'" + cantidad + "', ,'" + pagoTot + ", ,'" + anticipo + "'') ");

            }

            JOptionPane.showMessageDialog(null, "Data Seved");

        } catch (HeadlessException | SQLException e) {
            System.out.println(e);
        }

        try {

            String id = numeroDeVenta.getText();
            Statement s = dB.miConexion().createStatement();
            s.executeUpdate("UPDATE  extra SET val='" + id + "' WHERE exid = 1");

        } catch (SQLException e) {
            System.out.println(e);
        }

        try {

            HashMap para = new HashMap();

            para.put("inv_id", numeroDeVenta.getText());

        } catch (Exception e) {
        }


    }//GEN-LAST:event_botonFacturarActionPerformed

    private void cajaCantidadesProductoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cajaCantidadesProductoKeyReleased

        calculosPrecioProductos();
    }//GEN-LAST:event_cajaCantidadesProductoKeyReleased

    private void comboProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboProductosActionPerformed

        String nombre = comboProductos.getSelectedItem().toString();

        System.out.println(codigoDeTienda);
        try {
            Statement s = dB.miConexion().createStatement();
            ResultSet rs = s.executeQuery("SELECT  codigo, precio, cantidad FROM tabla_productos  WHERE nombre ='" + nombre + "'      ");
            if (rs.next()) {

                precioUnitario.setText(rs.getString("precio"));
                codigoP.setText(rs.getString("codigo"));
                existenciasTotales.setText(rs.getString("cantidad"));
            }

            calculosPrecioProductos();

        } catch (SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "No existe la tieda");
        }
        verificacion();

    }//GEN-LAST:event_comboProductosActionPerformed

    private void cajaTiendaEntregaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cajaTiendaEntregaKeyReleased
        // BUSCA POR COINCIDENCIA DE NOMBRE

        String nombre = cajaTiendaEntrega.getText();
        try {
            DefaultTableModel dtm = (DefaultTableModel) tablaDatosJ.getModel();
            dtm.setRowCount(0);
            Statement s = dB.miConexion().createStatement();

            ResultSet rs = s.executeQuery("SELECT * FROM tabla_clientes WHERE nombre LIKE '%" + nombre + "%' ");
            while (rs.next()) {
                Vector v = new Vector();
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                v.add(rs.getString(6));
                v.add(rs.getString(7));
                v.add(rs.getString(8));
                dtm.addRow(v);

                while (rs.last() || rs.first() || rs.previous()) {
                    System.out.println("entra 1");
                    dtm.setRowCount(0);
                }

            }

        } catch (SQLException e) {

        }
    }//GEN-LAST:event_cajaTiendaEntregaKeyReleased

    private void tablaFacturacionFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tablaFacturacionFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_tablaFacturacionFocusGained

    private void botonFacturar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonFacturar1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_botonFacturar1ActionPerformed

    private void pagoCreditoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pagoCreditoKeyReleased
        // TODO add your handling code here:
        tot();
        binario = true;
    }//GEN-LAST:event_pagoCreditoKeyReleased

    private void cajaTiendaSolicitudKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cajaTiendaSolicitudKeyReleased
        // TODO add your handling code here:
        codigoDeTienda = Integer.valueOf(cajaTiendaSolicitud.getText());
    }//GEN-LAST:event_cajaTiendaSolicitudKeyReleased

    private void iniciarCargaDeComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iniciarCargaDeComboActionPerformed
        // TODO add your handling code here:
        cargarDatos();
    }//GEN-LAST:event_iniciarCargaDeComboActionPerformed

    private void tablaDatosJMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaDatosJMouseClicked

    }//GEN-LAST:event_tablaDatosJMouseClicked

    private void cajaNombreClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cajaNombreClienteKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaNombreClienteKeyReleased

    private void cajaFechaRealizadaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cajaFechaRealizadaKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaFechaRealizadaKeyReleased

    private void cajaNombreClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaNombreClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaNombreClienteActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAniadirAlPedido;
    private javax.swing.JButton botonFacturar;
    private javax.swing.JButton botonFacturar1;
    private javax.swing.JButton botonQuitarDelPedido;
    private javax.swing.JButton botonQuitarTodo;
    private javax.swing.JTextField cajaCantidadesProducto;
    private javax.swing.JTextField cajaFechaRealizada;
    private javax.swing.JTextField cajaNombreCliente;
    private javax.swing.JTextField cajaTiendaEntrega;
    private javax.swing.JTextField cajaTiendaSolicitud;
    private javax.swing.JLabel cantidadTotal;
    private javax.swing.JLabel codigoP;
    private javax.swing.JComboBox<String> comboProductos;
    private javax.swing.JLabel existenciasTotales;
    private javax.swing.JButton iniciarCargaDeCombo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel numeroDeVenta;
    private javax.swing.JTextField pagoCredito;
    private javax.swing.JTextField pagoEnEfectivo;
    private javax.swing.JLabel pagoTotal;
    private javax.swing.JLabel precioT;
    private javax.swing.JLabel precioUnitario;
    private javax.swing.JLabel saldoRestante;
    private javax.swing.JTable tablaDatosJ;
    private javax.swing.JTable tablaFacturacion;
    // End of variables declaration//GEN-END:variables
}
