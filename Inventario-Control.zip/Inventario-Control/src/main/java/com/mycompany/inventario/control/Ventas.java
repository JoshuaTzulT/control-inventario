package com.mycompany.inventario.control;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 * Esta clase está relacionada con los objetos de la sección de ventas de la GUI
 *
 * @author JoshuaT
 */
public final class Ventas extends javax.swing.JPanel {//Inicio de la clase ventas

    public static String codigoDeTienda;
    public static Double pagadoUno;
    public static Double totUno;
    public static Double pagadoDos;
    public static Double totDos;
    public static Double restanteAPagar = 0.0;
    public static String codigo = "0";
    public static String clien_id = "0";
    public static String cliente_ID;
    public static boolean binario = false;
    private static String nombre_cliente;
    private static String indice;
    private static double comparacion = 0;
    private static double cantidadRequerida = 0;

    /**
     * Método constructor de la clase Ventas
     */
    public Ventas() {
        initComponents();

    }

    /**
     * Este método permte mosrar los productos existentes en la sección de
     * ventas
     */
    public void cargarDatos() {

        try {
            Statement s = dB.miConexion().createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM tabla_productos WHERE tiendaid = '" + codigoDeTienda + "'");
            Vector v = new Vector();

            while (rs.next()) {//inicio bucle while
                v.add(rs.getString("nombre"));
                DefaultComboBoxModel dcbm = new DefaultComboBoxModel(v);
                comboProductos.setModel(dcbm);
            }//fin bucle while

        } catch (SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "No existe la tienda ingresada");
        }
        try {
            Statement s = dB.miConexion().createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM extra WHERE exid =1");
            if (rs.next()) {
                numeroDeVenta.setText(rs.getString("val"));
            }

        } catch (SQLException e) {
        }

        int i = Integer.valueOf(numeroDeVenta.getText());
        i++;
        numeroDeVenta.setText(String.valueOf(i));
    }

    /**
     * Este métodp érmite calcular los totales a pagar por el cliente
     */
    public void calculosPrecioProductos() {

        Double cantidad = Double.valueOf(cajaCantidadesProducto.getText());
        verificacion();
        Double precio = Double.valueOf(precioUnitario.getText());
        Double tot;
        tot = cantidad * precio;
        precio_tot.setText(String.valueOf(tot));

    }

    /**
     * Este método permite la verificación si "X" producto tiene suficientes
     * existencias.
     */
    public void verificacion() {
        cantidadRequerida = Double.valueOf(cajaCantidadesProducto.getText());
        String id = comboProductos.getSelectedItem().toString();
        try {
            Statement sDos = dB.miConexion().createStatement();
            ResultSet rsDos = sDos.executeQuery("SELECT codigo FROM tabla_productos  WHERE nombre ='" + id + "'  ");
            if (rsDos.next()) {
                String val = rsDos.getObject(1).toString();
                indice = val;
            }

            Statement s = dB.miConexion().createStatement();
            ResultSet rs = s.executeQuery("SELECT cantidad FROM tabla_productos WHERE codigo ='" + indice + "' ");
            if (rs.next()) {
                int val = Integer.parseInt(rs.getObject(1).toString());
                comparacion = (double) val;
                System.out.println(val);
            }

        } catch (SQLException e) {

            System.out.println(e);
        }

    }

    /**
     * Este método permite mostrar el total de las compras realizadas
     */
    public void carritoTotal() {
        int numFila = tablaFacturacion.getRowCount();
        double total = 0;
        for (int i = 0; i < numFila; i++) {

            double valor = Double.valueOf(tablaFacturacion.getValueAt(i, 5).toString());
            total += valor;
        }
        pagoTotal.setText(Double.toString(total));

        int numeroDeFilas = tablaFacturacion.getRowCount();

        double totales = 0;

        for (int i = 0; i < numeroDeFilas; i++) {

            double valores = Double.valueOf(tablaFacturacion.getValueAt(i, 3).toString());
            totales += valores;
        }
        cantidadTotal.setText(Double.toString(totales));

    }

    /**
     * Este método distingue si se está pagando en efectio o con credito
     */
    public void tot() {

        if (binario == true) {
            pagadoUno = Double.valueOf(pagoCredito.getText());
            totUno = Double.valueOf(pagoTotal.getText());
            System.out.println(pagadoUno);
            restanteAPagar = pagadoUno - totUno;
            saldoRestante.setText(String.valueOf(restanteAPagar));
        }
        if (binario == false) {
            pagadoDos = Double.valueOf(pagoEnEfectivo.getText());
            totDos = Double.valueOf(pagoTotal.getText());
            restanteAPagar = pagadoDos - totDos;
            saldoRestante.setText(String.valueOf(restanteAPagar));

        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        botonFacturar1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        numeroDeVenta = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cajaBusquedaDos = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaFacturacion = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        pagoEnEfectivo = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        pagoCredito = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaDatosJ = new javax.swing.JTable();
        jPanel10 = new javax.swing.JPanel();
        comboProductos = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        cajaCantidadesProducto = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        codigoPr = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        precio_tot = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        precioUnitario = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        existenciasTotales = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        botonFacturar = new javax.swing.JButton();
        saldoRestante = new javax.swing.JLabel();
        pagoTotal = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        cantidadTotal = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        botonAniadirAlPedido = new javax.swing.JButton();
        botonQuitarDelPedido = new javax.swing.JButton();
        botonQuitarTodo = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        cajaEscogerTienda = new javax.swing.JTextField();
        iniciarCargaDeCombo = new javax.swing.JButton();

        botonFacturar1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        botonFacturar1.setText("Facturar");
        botonFacturar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonFacturar1ActionPerformed(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        numeroDeVenta.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        numeroDeVenta.setText("01");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("FACTURA:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Cliente:");

        cajaBusquedaDos.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        cajaBusquedaDos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cajaBusquedaDosKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(156, 156, 156)
                .addComponent(cajaBusquedaDos, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(numeroDeVenta)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(numeroDeVenta)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(cajaBusquedaDos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 9, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        tablaFacturacion.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        tablaFacturacion.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Factura", "Nombre", "Codigo", "Cantidad", "Precio Unitario", "Precio Total"
            }
        ));
        tablaFacturacion.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tablaFacturacionFocusGained(evt);
            }
        });
        jScrollPane1.setViewportView(tablaFacturacion);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("Efectivo:");

        pagoEnEfectivo.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        pagoEnEfectivo.setText("0");
        pagoEnEfectivo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                pagoEnEfectivoKeyReleased(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel13.setText("Credito");

        pagoCredito.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        pagoCredito.setText("0");
        pagoCredito.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                pagoCreditoKeyReleased(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setText("OPCIONES DE PAGO:");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addComponent(pagoEnEfectivo, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(113, 113, 113)
                        .addComponent(jLabel13)
                        .addGap(31, 31, 31)
                        .addComponent(pagoCredito, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(231, 231, 231)
                        .addComponent(jLabel14)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(pagoCredito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pagoEnEfectivo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15))
        );

        jPanel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        tablaDatosJ.setFont(new java.awt.Font("DejaVu Sans", 0, 8)); // NOI18N
        tablaDatosJ.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "NIT", "Telefono", "Credito", "DPI", "Email", "Direccion"
            }
        ));
        tablaDatosJ.getTableHeader().setReorderingAllowed(false);
        tablaDatosJ.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaDatosJMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tablaDatosJ);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 759, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE)
        );

        jPanel10.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        comboProductos.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        comboProductos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Despliegue" }));
        comboProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboProductosActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("Producto :");

        cajaCantidadesProducto.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        cajaCantidadesProducto.setText("0");
        cajaCantidadesProducto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cajaCantidadesProductoKeyReleased(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("Cantidad:");

        codigoPr.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        codigoPr.setText("0");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("Precio Total:");

        precio_tot.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        precio_tot.setText("00.00");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Precio Unitario:");

        precioUnitario.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        precioUnitario.setText("00.00");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setText("Codigo Prod:");

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel12.setText("Existencias:");

        existenciasTotales.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        existenciasTotales.setText("00.00");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(cajaCantidadesProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(comboProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(precioUnitario, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(existenciasTotales, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(precio_tot, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(67, 67, 67)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(codigoPr, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(25, 25, 25))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel12))
                        .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cajaCantidadesProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(comboProductos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 5, Short.MAX_VALUE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(precioUnitario)
                            .addComponent(existenciasTotales)
                            .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(precio_tot)
                                .addComponent(codigoPr)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        botonFacturar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        botonFacturar.setText("Facturar");
        botonFacturar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonFacturarActionPerformed(evt);
            }
        });

        saldoRestante.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        saldoRestante.setText("00.00");
        saldoRestante.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        pagoTotal.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        pagoTotal.setText("00.00");
        pagoTotal.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Balance: ");

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel10.setText("Cantidad Total:");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Cantidad total de articulos: ");

        cantidadTotal.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cantidadTotal.setText("00");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botonFacturar, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(cantidadTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(pagoTotal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(saldoRestante, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(cantidadTotal)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pagoTotal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(saldoRestante, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(botonFacturar, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        botonAniadirAlPedido.setText("Añadir al carrito");
        botonAniadirAlPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAniadirAlPedidoActionPerformed(evt);
            }
        });

        botonQuitarDelPedido.setText("Quitar");
        botonQuitarDelPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonQuitarDelPedidoActionPerformed(evt);
            }
        });

        botonQuitarTodo.setText("Quitar Todo");
        botonQuitarTodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonQuitarTodoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botonAniadirAlPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonQuitarDelPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonQuitarTodo, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(botonAniadirAlPedido)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonQuitarDelPedido)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonQuitarTodo)
                .addGap(0, 0, 0))
        );

        jPanel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel16.setText("INGRESE EL CODIGO DE LA TIENDA EN OPERACION:");

        cajaEscogerTienda.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        cajaEscogerTienda.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cajaEscogerTiendaKeyReleased(evt);
            }
        });

        iniciarCargaDeCombo.setText("INICIAR");
        iniciarCargaDeCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iniciarCargaDeComboActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(cajaEscogerTienda, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(iniciarCargaDeCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(184, 184, 184))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(cajaEscogerTienda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(iniciarCargaDeCombo))
                .addGap(0, 37, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(28, 28, 28)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 17, Short.MAX_VALUE))
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Este método permite añadir los elementos seleccionados al carrito de
     * compras
     *
     * @param evt
     */
    private void botonAniadirAlPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAniadirAlPedidoActionPerformed

        if (getCantidadRequerida() > getComparacion()) {
            JOptionPane.showMessageDialog(null, "PRODUCTO EN INVENTARIO INSUFICIENTE");
        } else if (getCantidadRequerida() <= getComparacion()) {
            DefaultTableModel dtm = (DefaultTableModel) tablaFacturacion.getModel();

            Vector v = new Vector();
            v.add(numeroDeVenta.getText());
            v.add(comboProductos.getSelectedItem().toString());
            v.add(codigoPr.getText());
            v.add(cajaCantidadesProducto.getText());
            v.add(precioUnitario.getText());
            v.add(precio_tot.getText()); // get totle precio
            dtm.addRow(v);

            carritoTotal();
            tot();
        }


    }//GEN-LAST:event_botonAniadirAlPedidoActionPerformed
    /**
     * Este método permite quietar un elemento no deseado de la seccion de
     * ventas.
     *
     * @param evt
     */
    private void botonQuitarDelPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonQuitarDelPedidoActionPerformed

        try {

            DefaultTableModel dtm = (DefaultTableModel) tablaFacturacion.getModel();
            int fl = tablaFacturacion.getSelectedRow();

            dtm.removeRow(fl);

        } catch (Exception e) {
        }

        carritoTotal();
        tot();


    }//GEN-LAST:event_botonQuitarDelPedidoActionPerformed

    /**
     * Este método permite quitar todos los elementos seleccionados con
     * anterioridd.
     *
     * @param evt
     */
    private void botonQuitarTodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonQuitarTodoActionPerformed

        DefaultTableModel dtm = (DefaultTableModel) tablaFacturacion.getModel();
        dtm.setRowCount(0);
        carritoTotal();
        tot();
    }//GEN-LAST:event_botonQuitarTodoActionPerformed

    /**
     * Este método es llamado cuando se escribe en el textbox de pago en
     * efectivo
     *
     * @param evt
     */
    private void pagoEnEfectivoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pagoEnEfectivoKeyReleased
        binario = false;
        tot();

    }//GEN-LAST:event_pagoEnEfectivoKeyReleased
    /**
     * Este método se utilizar para indicar al sistema que los elementos
     * seleccionados se deben descontar del inventario y realizar posteriores
     * procedimientos.
     *
     * @param evt
     */
    private void botonFacturarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonFacturarActionPerformed

        try {

            DefaultTableModel dtm = (DefaultTableModel) tablaDatosJ.getModel();
            int fila = tablaDatosJ.getSelectedRow();
            String num_factura = numeroDeVenta.getText();
            String cantTotal = cantidadTotal.getText();
            String paTot = pagoTotal.getText();
            String saldo = saldoRestante.getText();
            Double tot = Double.valueOf(pagoTotal.getText());
            Double pid = Double.valueOf(pagoEnEfectivo.getText());
            String Estado = null;

            if (pid.equals(0.0)) {

                Estado = "NO-PAGADO";

            } else if (tot > pid) {
                Estado = "PARCIALMENTE";

            } else if (tot <= pid) {
                Estado = "PAGADO";
            }

            Statement ss = dB.miConexion().createStatement();
            ss.executeUpdate("INSERT INTO tabla_ventas (numer_factura, cliente_id, nombre_cliente, cantidad_total, pago_total, estado, saldo) VALUES ('" + num_factura + "','" + clien_id + "', '" + nombre_cliente + "', '" + cantTotal + "','" + paTot + "','" + Estado + "','" + saldo + "')");

            if (binario == true) {
                String clie_IDT = dtm.getValueAt(fila, 1).toString();
                System.out.println("VALOR DE " + clie_IDT);
                ResultSet rs = ss.executeQuery("SELECT credito FROM tabla_clientes WHERE nit = '" + clie_IDT + "'");
                System.out.println("CUS ID:" + clie_IDT);
                double val;
                if (rs.next()) {
                    val = ((Number) rs.getObject(1)).intValue();
                    System.out.println("EL SALDO : " + val);
                    double nuevoCredito = val - pagadoUno;
                    System.out.println(nuevoCredito);

                    ss.executeUpdate("UPDATE tabla_clientes SET credito =  '" + nuevoCredito + "'  WHERE nit = '" + clie_IDT + "'");
                }

            }
        } catch (NumberFormatException | SQLException e) {
            System.out.println(e);
        }
        System.out.println("NO SE SI SEA ACA EN LO DE SET  ");

        try {

            String id = numeroDeVenta.getText();
            Statement s = dB.miConexion().createStatement();
            s.executeUpdate("UPDATE  extra SET val='" + id + "' WHERE exid = 1");

        } catch (SQLException e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_botonFacturarActionPerformed

    /**
     * Este método es llamado al escribir en el textbox que indica las
     * cantidades deseadas de un producto
     *
     * @param evt
     */
    private void cajaCantidadesProductoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cajaCantidadesProductoKeyReleased

        calculosPrecioProductos();
    }//GEN-LAST:event_cajaCantidadesProductoKeyReleased
    /**
     * Este método es el encargado de desplegar los productos existentes en la
     * interfaz de usuario
     *
     * @param evt
     */
    private void comboProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboProductosActionPerformed

        String nombre = comboProductos.getSelectedItem().toString();

        System.out.println(codigoDeTienda);
        try {

            Statement s = dB.miConexion().createStatement();
            ResultSet rs = s.executeQuery("SELECT  codigo, precio, cantidad FROM tabla_productos  WHERE nombre ='" + nombre + "'      ");
            if (rs.next()) {
                precioUnitario.setText(rs.getString("precio"));
                codigoPr.setText(rs.getString("codigo"));
                existenciasTotales.setText(rs.getString("cantidad"));
            }

            calculosPrecioProductos();

        } catch (SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "No existe la tieda");
        }
        verificacion();

    }//GEN-LAST:event_comboProductosActionPerformed
    /**
     * Este método permite seleccionar individualmente algun producot desplegado
     *
     * @param evt
     */
    private void tablaDatosJMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaDatosJMouseClicked
        //AL HACER CLICK SOBRE LA FILA DESEADA, AUTOMATICAMENTE SE RELLENAN LOS CAMPOS
        int fila = tablaDatosJ.getSelectedRow();
        String nombre = tablaDatosJ.getValueAt(fila, 1).toString();
        String nit = tablaDatosJ.getValueAt(fila, 2).toString();
        nombre_cliente = nombre;
        clien_id = nit;

    }//GEN-LAST:event_tablaDatosJMouseClicked
    /**
     * Este método permite buscar clientes existentes por coincidencias a la
     * hora de realizar una venta.
     *
     * @param evt
     */
    private void cajaBusquedaDosKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cajaBusquedaDosKeyReleased
        // BUSCA POR COINCIDENCIA DE NOMBRE

        String nombre = cajaBusquedaDos.getText();
        try {
            DefaultTableModel dtm = (DefaultTableModel) tablaDatosJ.getModel();
            dtm.setRowCount(0);
            Statement s = dB.miConexion().createStatement();

            ResultSet rs = s.executeQuery("SELECT * FROM tabla_clientes WHERE nombre LIKE '%" + nombre + "%' ");
            while (rs.next()) {
                Vector v = new Vector();
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                v.add(rs.getString(6));
                v.add(rs.getString(7));
                v.add(rs.getString(8));
                dtm.addRow(v);

                while (rs.last() || rs.first() || rs.previous()) {
                    System.out.println("entra 1");
                    dtm.setRowCount(0);
                }

            }

        } catch (SQLException e) {

        }
    }//GEN-LAST:event_cajaBusquedaDosKeyReleased

    private void tablaFacturacionFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tablaFacturacionFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_tablaFacturacionFocusGained

    private void botonFacturar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonFacturar1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_botonFacturar1ActionPerformed
    /**
     * Este método es llamado al escribir en el textbox destinado al pago con
     * credito.
     *
     * @param evt
     */
    private void pagoCreditoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pagoCreditoKeyReleased
        // TODO add your handling code here:
        tot();
        binario = true;
    }//GEN-LAST:event_pagoCreditoKeyReleased
    /**
     * Este método es el correspondiente al textbox que permite ingresar el
     * codigo de la tienda deseada
     *
     * @param evt
     */
    private void cajaEscogerTiendaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cajaEscogerTiendaKeyReleased
        // TODO add your handling code here:
        codigoDeTienda = cajaEscogerTienda.getText();
    }//GEN-LAST:event_cajaEscogerTiendaKeyReleased
    /**
     * al interactuar con las opciones de productoes este método es llamado.
     *
     * @param evt
     */
    private void iniciarCargaDeComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iniciarCargaDeComboActionPerformed
        // TODO add your handling code here:
        cargarDatos();
    }//GEN-LAST:event_iniciarCargaDeComboActionPerformed

    //algunos getter  y setters
    public static double getCantidadRequerida() {
        return cantidadRequerida;
    }

    public static void setCantidadRequerida(double cantidadRequerida) {
        Ventas.cantidadRequerida = cantidadRequerida;
    }

    public static double getComparacion() {
        return comparacion;
    }

    public static void setComparacion(double comparacion) {
        Ventas.comparacion = comparacion;
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAniadirAlPedido;
    private javax.swing.JButton botonFacturar;
    private javax.swing.JButton botonFacturar1;
    private javax.swing.JButton botonQuitarDelPedido;
    private javax.swing.JButton botonQuitarTodo;
    private javax.swing.JTextField cajaBusquedaDos;
    private javax.swing.JTextField cajaCantidadesProducto;
    private javax.swing.JTextField cajaEscogerTienda;
    private javax.swing.JLabel cantidadTotal;
    private javax.swing.JLabel codigoPr;
    private javax.swing.JComboBox<String> comboProductos;
    private javax.swing.JLabel existenciasTotales;
    private javax.swing.JButton iniciarCargaDeCombo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel numeroDeVenta;
    private javax.swing.JTextField pagoCredito;
    private javax.swing.JTextField pagoEnEfectivo;
    private javax.swing.JLabel pagoTotal;
    private javax.swing.JLabel precioUnitario;
    private javax.swing.JLabel precio_tot;
    private javax.swing.JLabel saldoRestante;
    private javax.swing.JTable tablaDatosJ;
    private javax.swing.JTable tablaFacturacion;
    // End of variables declaration//GEN-END:variables
}//FIN DE LA CLASE VENTAS

