package com.mycompany.inventario.control;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Este clase es la encargada de gestionar la conexión de la aplicación a la
 * base de datos.
 *
 * @author JoshuaT
 */
public class dB {//Inicio de la clase dB

    public static Connection miConexion() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/sisinventario?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", "root", "11112222");
            return con;
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
            return null;
        }
    }

}//FIN DE LA CLASE dB
