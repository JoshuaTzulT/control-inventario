package com.mycompany.inventario.control;

import java.awt.HeadlessException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 * Esta clase define los objetos contenidos en la interfaz grafica de la seccion
 * de Productos.
 *
 * @author JoshuaT
 */
public final class Productos extends javax.swing.JPanel {//Inicio de la clase Productos

    public Productos() {//inicio del constructor 
        initComponents();
        tablaEnPantalla();
    }//fin del constructor

    /**
     * Este método muestra en la GUI, la tabla con los datos contenidos en la
     * base de datos, permitiendo así un interfaz mas amigable con el usuario.
     */
    public void tablaEnPantalla() {//incio método

        try {
            DefaultTableModel dtm = (DefaultTableModel) tablaDatosJ.getModel();
            dtm.setRowCount(0);

            Statement s = dB.miConexion().createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM tabla_productos ORDER BY codigo DESC");

            while (rs.next()) {//inicio del bucle while 
                Vector v = new Vector();
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                v.add(rs.getString(6));
                v.add(rs.getString(7));
                v.add(rs.getString(8));
                v.add(rs.getString(9));

                dtm.addRow(v);
            }//fin bucle while
        } catch (SQLException e) {
            System.out.println(e);
        }

    }//fin metodo

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cajaNombre = new javax.swing.JTextField();
        cajaFabricante = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        cajaCodigo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cajaCantidad = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        cajaPrecio = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        cajaGarantia = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        botonGuardar = new javax.swing.JButton();
        botonActualizar = new javax.swing.JButton();
        botonBorrar = new javax.swing.JButton();
        cajaDescripcion = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        cajaTiendaID = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaDatosJ = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        cajaBusqueda = new javax.swing.JTextField();
        botonBuscarID = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        cajaBusquedaDos = new javax.swing.JTextField();

        setPreferredSize(new java.awt.Dimension(1179, 782));

        jPanel1.setPreferredSize(new java.awt.Dimension(933, 658));

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel1.setText("Nombre:");

        cajaNombre.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        cajaFabricante.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        jLabel2.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel2.setText("Fabricante");

        cajaCodigo.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        jLabel3.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel3.setText("Código:");

        cajaCantidad.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        jLabel4.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel4.setText("Cantidad:");

        cajaPrecio.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        jLabel5.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel5.setText("Precio:");

        cajaGarantia.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        jLabel6.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel6.setText("Descripción:");

        jLabel7.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel7.setText("Garantia");

        botonGuardar.setText("Guardar");
        botonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarActionPerformed(evt);
            }
        });

        botonActualizar.setText("Actualizar");
        botonActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonActualizarActionPerformed(evt);
            }
        });

        botonBorrar.setText("Borrar");
        botonBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBorrarActionPerformed(evt);
            }
        });

        cajaDescripcion.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        jLabel11.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel11.setText("TiendaID");

        cajaTiendaID.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cajaCantidad, javax.swing.GroupLayout.DEFAULT_SIZE, 203, Short.MAX_VALUE)
                            .addComponent(cajaCodigo)
                            .addComponent(cajaFabricante)
                            .addComponent(cajaNombre)))
                    .addComponent(jLabel4))
                .addGap(159, 159, 159)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(26, 26, 26)))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel7)
                            .addGap(33, 33, 33)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(41, 41, 41)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cajaPrecio, javax.swing.GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
                    .addComponent(cajaGarantia)
                    .addComponent(cajaTiendaID)
                    .addComponent(cajaDescripcion))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botonActualizar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonBorrar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonGuardar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(cajaNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(cajaFabricante, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(cajaCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(cajaTiendaID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonGuardar))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(cajaDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonActualizar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(cajaGarantia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonBorrar))))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cajaCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(cajaPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0))
        );

        tablaDatosJ.setFont(new java.awt.Font("DejaVu Sans", 0, 8)); // NOI18N
        tablaDatosJ.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Fabricante", "Codigo", "Cantidad", "Precio", "TiendaID", "Descripcion", "Garantia"
            }
        ));
        tablaDatosJ.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaDatosJMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaDatosJ);

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel8.setFont(new java.awt.Font("DejaVu Sans", 1, 18)); // NOI18N
        jLabel8.setText("INFORMACIÓN DE LOS PRODUCTOS:");

        jLabel9.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel9.setText("ID:");

        cajaBusqueda.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        botonBuscarID.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        botonBuscarID.setText("Buscar");
        botonBuscarID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBuscarIDActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(278, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addGap(18, 18, 18)
                .addComponent(cajaBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(75, 75, 75)
                .addComponent(botonBuscarID, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(210, 210, 210))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel8)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jLabel8)
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cajaBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(botonBuscarID))
                .addGap(0, 0, 0))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel10.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel10.setText("BUSQUEDA: ");

        cajaBusquedaDos.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        cajaBusquedaDos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cajaBusquedaDosKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(277, 277, 277)
                .addComponent(jLabel10)
                .addGap(45, 45, 45)
                .addComponent(cajaBusquedaDos, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cajaBusquedaDos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(0, 0, 0))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(211, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 246, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 782, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Método relacionado con el boton de guardar nuevos registros en la base de
     * datos.
     *
     * @param evt
     */
    private void botonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarActionPerformed
        //GUARDAR NUEVOS REGISTROS SOBRE PRODUCTOS
        String nombre = cajaNombre.getText();
        String fabricante = cajaFabricante.getText();
        String codigo = cajaCodigo.getText();
        String cantidad = cajaCantidad.getText();
        String precio = cajaPrecio.getText();
        String descripcion = cajaDescripcion.getText();
        String garantia = cajaGarantia.getText();
        String cajaId = cajaTiendaID.getText();

        try {
            Statement s = dB.miConexion().createStatement();
            s.executeUpdate("INSERT INTO tabla_productos (descriptivo, nombre, fabricante, codigo, cantidad, precio, tiendaid, descripcion, garantia) VALUES ('PRODUCTO' , '" + nombre + "', '" + fabricante + "', '" + codigo + "', '" + cantidad + "', '" + precio + "', '" + cajaId + "', '" + descripcion + "','" + garantia + "')");
            JOptionPane.showMessageDialog(null, "Cambios GUARDADOS");
        } catch (SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "CUIDADO! Campos vacios y/o erroneos");
        }
        tablaEnPantalla();
    }//GEN-LAST:event_botonGuardarActionPerformed

    /**
     * Método relacionado con el textbox de busqueda de productos por ID.
     *
     * @param evt
     */
    private void botonBuscarIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBuscarIDActionPerformed
        // BUSCAR PRODUCTO POR ID
        String busqueda = cajaBusqueda.getText();

        try {
            Statement s = dB.miConexion().createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM tabla_productos WHERE codigo = '" + busqueda + "'");

            if (rs.next()) {//inicio condicional 
                cajaNombre.setText(rs.getString("nombre"));
                cajaFabricante.setText(rs.getString("fabricante"));
                cajaCodigo.setText(rs.getString("codigo"));
                cajaCantidad.setText(rs.getString("cantidad"));
                cajaPrecio.setText(rs.getString("precio"));
                cajaDescripcion.setText(rs.getString("descripcion"));
                cajaGarantia.setText(rs.getString("garantia"));
                cajaTiendaID.setText(rs.getString("tiendaid"));
            }//fin condicional.

        } catch (SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "CODIGO INCORRECTO");
        }
        tablaEnPantalla();
    }//GEN-LAST:event_botonBuscarIDActionPerformed

    /**
     * Este método esta relacionado con el boton que permite actuzalizar los
     * registros existentes en la base de datos.
     *
     * @param evt
     */
    private void botonActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonActualizarActionPerformed
        // ACTUALIZA LOS CAMBIOS HECHOS
        String id = cajaBusqueda.getText();
        String nombre = cajaNombre.getText();
        String fabricante = cajaFabricante.getText();
        String codigo = cajaCodigo.getText();
        String cantidad = cajaCantidad.getText();
        String precio = cajaPrecio.getText();
        String descripcion = cajaDescripcion.getText();
        String garantia = cajaGarantia.getText();
        String cajaId = cajaTiendaID.getText();
        try {
            Statement s = dB.miConexion().createStatement();
            s.executeUpdate("UPDATE tabla_productos SET  nombre='" + nombre + "', fabricante='" + fabricante + "', codigo='" + codigo + "', cantidad='" + cantidad + "', precio='" + precio + "', tiendaid= '" + cajaId + "', descripcion='" + descripcion + "', garantia='" + garantia + "' WHERE codigo = '" + id + "' ");
            JOptionPane.showMessageDialog(null, "Datos ACTUALIZADOS");
        } catch (HeadlessException | SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "CUIDADO! los cambios no pudieron completarse");
        }
        tablaEnPantalla();
    }//GEN-LAST:event_botonActualizarActionPerformed

    /**
     * Este método esta relacionado con el boton que permite borrar registros
     * existentes en la base de datos.
     *
     * @param evt
     */
    private void botonBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBorrarActionPerformed
        // BORRAR EL REGISTRO DE ALGUNA PRODUCTO
        String id = cajaBusqueda.getText();

        try {
            Statement s = dB.miConexion().createStatement();
            s.executeUpdate("DELETE FROM tabla_productos WHERE codigo = '" + id + "'");
            JOptionPane.showMessageDialog(null, "REGISTRO BORRADO!");
        } catch (HeadlessException | SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "NO SE PUDO COMPLETAR LA ACCIÓN");
        }
        tablaEnPantalla();
    }//GEN-LAST:event_botonBorrarActionPerformed

    /**
     * Este método esta permite que la fila seleccionada con información,
     * rellene automaticamente los textbox con dicha información.
     *
     * @param evt
     */
    private void tablaDatosJMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaDatosJMouseClicked
        //AL HACER CLICK SOBRE LA FILA DESEADA, AUTOMATICAMENTE SE RELLENAN LOS CAMPOS

        int fila = tablaDatosJ.getSelectedRow();

        String id = tablaDatosJ.getValueAt(fila, 2).toString();
        String nombre = tablaDatosJ.getValueAt(fila, 0).toString();
        String fabricante = tablaDatosJ.getValueAt(fila, 1).toString();
        String codigo = tablaDatosJ.getValueAt(fila, 2).toString();
        String cantidad = tablaDatosJ.getValueAt(fila, 3).toString();
        String precio = tablaDatosJ.getValueAt(fila, 4).toString();
        String cajaId = tablaDatosJ.getValueAt(fila, 5).toString();
        String descripcion = tablaDatosJ.getValueAt(fila, 6).toString();
        String garantia = tablaDatosJ.getValueAt(fila, 7).toString();

        cajaBusqueda.setText(id);
        cajaNombre.setText(nombre);
        cajaFabricante.setText(fabricante);
        cajaCodigo.setText(codigo);
        cajaCantidad.setText(cantidad);
        cajaPrecio.setText(precio);
        cajaDescripcion.setText(descripcion);
        cajaGarantia.setText(garantia);
        cajaTiendaID.setText(cajaId);

    }//GEN-LAST:event_tablaDatosJMouseClicked

    /**
     * Este método permite buscar productor por coincidencias de nombre y/o
     * código
     *
     * @param evt
     */
    private void cajaBusquedaDosKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cajaBusquedaDosKeyReleased
        // BUSCA POR COINCIDENCIA DE CODIGO/NOMBRE

        String nombre = cajaBusquedaDos.getText();
        try {
            DefaultTableModel dtm = (DefaultTableModel) tablaDatosJ.getModel();
            dtm.setRowCount(0);
            Statement s = dB.miConexion().createStatement();

            ResultSet rs = s.executeQuery("SELECT * FROM tabla_productos WHERE codigo LIKE '%" + nombre + "%' ORDER BY codigo");

            while (rs.next()) {//inicio bucle while

                Vector v = new Vector();

                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                v.add(rs.getString(6));
                v.add(rs.getString(7));
                v.add(rs.getString(8));
                v.add(rs.getString(9));
                dtm.addRow(v);

            }//fin bucle while
        } catch (SQLException e) {
            tablaEnPantalla();
        }

    }//GEN-LAST:event_cajaBusquedaDosKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonActualizar;
    private javax.swing.JButton botonBorrar;
    private javax.swing.JButton botonBuscarID;
    private javax.swing.JButton botonGuardar;
    private javax.swing.JTextField cajaBusqueda;
    private javax.swing.JTextField cajaBusquedaDos;
    private javax.swing.JTextField cajaCantidad;
    private javax.swing.JTextField cajaCodigo;
    private javax.swing.JTextField cajaDescripcion;
    private javax.swing.JTextField cajaFabricante;
    private javax.swing.JTextField cajaGarantia;
    private javax.swing.JTextField cajaNombre;
    private javax.swing.JTextField cajaPrecio;
    private javax.swing.JTextField cajaTiendaID;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaDatosJ;
    // End of variables declaration//GEN-END:variables
}//FIN DE LA CLASE PRODUCTOS
