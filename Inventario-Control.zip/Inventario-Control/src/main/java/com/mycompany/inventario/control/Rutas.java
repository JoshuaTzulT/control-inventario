package com.mycompany.inventario.control;

import java.awt.HeadlessException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 * Esta clase define los objetos contenidos en la interfaz grafica de la seccion
 * de Rutas.
 *
 * @author JoshuaT
 */
public final class Rutas extends javax.swing.JPanel {//Inicio de la clase Rutas

    /**
     * Método constructor de la clase Rutas
     */
    public Rutas() {//inicio del constructor
        initComponents();
        tablaEnPantalla();
    }//fin del constructor

    /**
     * Este método muestra en la GUI, la tabla con los datos contenidos en la
     * base de datos, permitiendo así un interfaz mas amigable con el usuario.
     */
    public void tablaEnPantalla() {//Inicio del método tablaEnPantalla.

        try {
            DefaultTableModel dtm = (DefaultTableModel) tablaDatosJ.getModel();
            dtm.setRowCount(0);
            Statement s = dB.miConexion().createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM tiempo_envio ORDER BY tiempo  ");

            while (rs.next()) {//inicio del bucle while
                Vector v = new Vector();
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                dtm.addRow(v);
            }//fin del bucle while
        } catch (SQLException e) {
            System.out.println(e);
        }

    }// fin del método tablaEnPantall

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cajaTiendaOrigen = new javax.swing.JTextField();
        cajaTiendaDestino = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        cajaTiempo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        botonGuardar = new javax.swing.JButton();
        botonActualizar = new javax.swing.JButton();
        botonBorrar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaDatosJ = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        cajaBusqueda = new javax.swing.JTextField();
        botonBuscarID = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        cajaBusquedaDos = new javax.swing.JTextField();

        setPreferredSize(new java.awt.Dimension(1179, 782));

        jPanel1.setPreferredSize(new java.awt.Dimension(933, 659));

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel1.setText("Tienda de origen: ");

        cajaTiendaOrigen.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        cajaTiendaDestino.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        cajaTiendaDestino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaTiendaDestinoActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel2.setText("Tienda Destino:");

        cajaTiempo.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        jLabel3.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel3.setText("Tiempo (DIAS):");

        botonGuardar.setText("Guardar");
        botonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarActionPerformed(evt);
            }
        });

        botonActualizar.setText("Actualizar");
        botonActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonActualizarActionPerformed(evt);
            }
        });

        botonBorrar.setText("Borrar");
        botonBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBorrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(botonGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(botonActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(botonBorrar, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(cajaTiendaOrigen, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(125, 125, 125)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(cajaTiendaDestino, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(54, 54, 54)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(cajaTiempo, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(51, 51, 51))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cajaTiendaOrigen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(cajaTiempo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(cajaTiendaDestino, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonGuardar)
                    .addComponent(botonActualizar)
                    .addComponent(botonBorrar))
                .addGap(0, 0, 0))
        );

        tablaDatosJ.setFont(new java.awt.Font("DejaVu Sans", 0, 8)); // NOI18N
        tablaDatosJ.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "", "Tienda de Origen", "Tienda de Destino", "Tiempo"
            }
        ));
        tablaDatosJ.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaDatosJMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaDatosJ);

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel8.setFont(new java.awt.Font("DejaVu Sans", 1, 18)); // NOI18N
        jLabel8.setText("INFORMACIÓN DE LAS RUTAS");

        jLabel9.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel9.setText("ID:");

        cajaBusqueda.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        botonBuscarID.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        botonBuscarID.setText("Buscar");
        botonBuscarID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBuscarIDActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel8)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addGap(18, 18, 18)
                .addComponent(cajaBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(botonBuscarID, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(241, 241, 241))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cajaBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(botonBuscarID)))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel10.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel10.setText("BUSQUEDA: ");

        cajaBusquedaDos.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        cajaBusquedaDos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cajaBusquedaDosKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(cajaBusquedaDos, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(272, 272, 272))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cajaBusquedaDos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(0, 0, 0))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 933, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(65, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 246, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
    }// </editor-fold>//GEN-END:initComponents

    /**
     * método del textbox que permite buscar por id el tiempo relacionado a dos
     * tiendas
     *
     * @param evt
     */
    private void botonBuscarIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBuscarIDActionPerformed
        // BUSCAR TIEMPO POR ID
        String busqueda = cajaBusqueda.getText();

        try {
            Statement s = dB.miConexion().createStatement();
            ResultSet rs = s.executeQuery(" SELECT * FROM tiempo_envio WHERE envid = '" + busqueda + "' ");

            if (rs.next()) {
                cajaTiendaOrigen.setText(rs.getString("tienda_uno"));
                cajaTiendaDestino.setText(rs.getString("tienda_dos"));
                cajaTiempo.setText(rs.getString("tiempo"));
            }

        } catch (SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "No hay coincidencias");
        }
        tablaEnPantalla();
    }//GEN-LAST:event_botonBuscarIDActionPerformed

    /**
     * Este método esta relacionado con la tabla que contiene los datos en la
     * aplicación, al hacer click sobre una fila de datos estos llenan
     * automaticamente los textbox.
     *
     * @param evt
     */
    private void tablaDatosJMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaDatosJMouseClicked
        //AL HACER CLICK SOBRE LA FILA DESEADA, AUTOMATICAMENTE SE RELLENAN LOS CAMPOS
        int fila = tablaDatosJ.getSelectedRow();

        String id = tablaDatosJ.getValueAt(fila, 0).toString();
        String origen = tablaDatosJ.getValueAt(fila, 1).toString();
        String destino = tablaDatosJ.getValueAt(fila, 2).toString();
        String tiempo = tablaDatosJ.getValueAt(fila, 3).toString();

        cajaBusqueda.setText(id);
        cajaTiendaOrigen.setText(origen);
        cajaTiendaDestino.setText(destino);
        cajaTiempo.setText(tiempo);

    }//GEN-LAST:event_tablaDatosJMouseClicked
    /**
     * Este método permite buscar las coincidencias de tiendas, codigo
     *
     * @param evt
     */
    private void cajaBusquedaDosKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cajaBusquedaDosKeyReleased
        // BUSCA POR COINCIDENCIA DE NOMBRE DE TIENDAS
        String tiempo = cajaBusquedaDos.getText();
        try {
            DefaultTableModel dtm = (DefaultTableModel) tablaDatosJ.getModel();
            dtm.setRowCount(0);
            Statement s = dB.miConexion().createStatement();

            ResultSet rs = s.executeQuery("SELECT * FROM tiempo_envio WHERE tienda_uno LIKE '%" + tiempo + "%' OR tienda_dos '%" + tiempo + "%' ");

            while (rs.next() || rs.previous()) {//inicio bucle while
                Vector v = new Vector();
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                dtm.addRow(v);
            }//fin bucle while
        } catch (SQLException e) {
            tablaEnPantalla();
        }

    }//GEN-LAST:event_cajaBusquedaDosKeyReleased

    /**
     * Este método está relacionado con el boton que permite eliminar datos de
     * la tabla
     *
     * @param evt
     */
    private void botonBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBorrarActionPerformed
        // BORRAR EL REGISTRO DE ALGUNA TIEMPO
        String id = cajaBusqueda.getText();

        try {
            Statement s = dB.miConexion().createStatement();
            s.executeUpdate("DELETE FROM tiempo_envio WHERE envid = '" + id + "'");
            JOptionPane.showMessageDialog(null, "REGISTRO BORRADO!");
        } catch (HeadlessException | SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "CUIDADO! La accion no pudo completarse");
        }
        tablaEnPantalla();
    }//GEN-LAST:event_botonBorrarActionPerformed

    /**
     * Este método esta relacionado con el boton que permite actualizar registro
     * en la base de datos.
     *
     * @param evt
     */
    private void botonActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonActualizarActionPerformed
        // ACTUALIZA LOS CAMBIOS HECHOS
        String id = cajaBusqueda.getText();
        String origen = cajaTiendaOrigen.getText();
        String destino = cajaTiendaDestino.getText();
        String tiempo = cajaTiempo.getText();

        try {
            Statement s = dB.miConexion().createStatement();
            s.executeUpdate("UPDATE tiempo_envio SET tienda_uno='" + origen + "', tienda_dos='" + destino + "', tiempo='" + tiempo + "' WHERE envid = '" + id + "' ");
            JOptionPane.showMessageDialog(null, "Datos ACTUALIZADOS");
        } catch (HeadlessException | SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "CUIDADO! Los cambios no pudieron guardarse");
        }
        tablaEnPantalla();
    }//GEN-LAST:event_botonActualizarActionPerformed

    /**
     * Este método esta relacionado con el boton que administra los nuevos
     * registros en la base de datos
     *
     * @param evt
     */
    private void botonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarActionPerformed
        //GUARDAR NUEVOS REGISTROS SOBRE TIENDAS
        String origen = cajaTiendaOrigen.getText();
        String destino = cajaTiendaDestino.getText();
        String tiempo = cajaTiempo.getText();

        try {
            Statement s = dB.miConexion().createStatement();
            s.executeUpdate("INSERT INTO tiempo_envio (descriptivo, tienda_uno, tienda_dos, tiempo) VALUES ('TIEMPO','" + origen + "', '" + destino + "', '" + tiempo + "')");
            JOptionPane.showMessageDialog(null, "Cambios GUARDADOS");
        } catch (SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "CUIDADO! Verifique que este ingresando datos correctos ");
        }
        tablaEnPantalla();
    }//GEN-LAST:event_botonGuardarActionPerformed

    /**
     * @deprecated @param evt
     */
    private void cajaTiendaDestinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaTiendaDestinoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaTiendaDestinoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonActualizar;
    private javax.swing.JButton botonBorrar;
    private javax.swing.JButton botonBuscarID;
    private javax.swing.JButton botonGuardar;
    private javax.swing.JTextField cajaBusqueda;
    private javax.swing.JTextField cajaBusquedaDos;
    private javax.swing.JTextField cajaTiempo;
    private javax.swing.JTextField cajaTiendaDestino;
    private javax.swing.JTextField cajaTiendaOrigen;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaDatosJ;
    // End of variables declaration//GEN-END:variables
}//fin de la clase rutas
