package com.mycompany.inventario.control;

import java.awt.HeadlessException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 * Esta clase contiene los objetos relacionados a seección Empleados de la GUI
 * del usuario.
 *
 * @author JoshuaT
 */
public final class Empleados extends javax.swing.JPanel {//Inicio de la clase Empleados

    public Empleados() {//Inicio del constructor 
        initComponents();
        tablaEnPantalla();
    }//fin del constructor

    /**
     * Este método es el encargado de mosrar los datos existentes de la base de
     * datos en la pantalla.
     */
    public void tablaEnPantalla() {//Inicio del metodo tablaEnPantalla

        try {
            DefaultTableModel dtm = (DefaultTableModel) tablaDatosJ.getModel();
            dtm.setRowCount(0);

            Statement s = dB.miConexion().createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM tabla_empleados ORDER BY  codigo DESC ");

            while (rs.next()) {//inicio del bucle while
                Vector v = new Vector();
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                v.add(rs.getString(6));
                v.add(rs.getString(7));
                v.add(rs.getString(8));

                dtm.addRow(v);
            }//fin del bucle while
        } catch (SQLException e) {
            System.out.println(e);
        }

    }//fin del método tablaEnPantalla

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cajaNombre = new javax.swing.JTextField();
        cajaNit = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cajaTelefono = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        cajaDpi = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        cajaCodigo = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        botonGuardar = new javax.swing.JButton();
        botonActualizar = new javax.swing.JButton();
        botonBorrar = new javax.swing.JButton();
        cajaCorreo = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        cajaDireccion = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaDatosJ = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        cajaBusqueda = new javax.swing.JTextField();
        botonBuscarID = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        cajaBusquedaDos = new javax.swing.JTextField();

        setPreferredSize(new java.awt.Dimension(1179, 782));

        jPanel1.setPreferredSize(new java.awt.Dimension(933, 659));

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel1.setText("Nombre:");

        cajaNombre.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        cajaNit.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        jLabel3.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel3.setText("NIT:");

        cajaTelefono.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        jLabel4.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel4.setText("Teléfono:");

        cajaDpi.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        jLabel5.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel5.setText("DPI:");

        cajaCodigo.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        jLabel6.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel6.setText("E-mail:");

        jLabel7.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel7.setText("Codigo:");

        botonGuardar.setText("Guardar");
        botonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarActionPerformed(evt);
            }
        });

        botonActualizar.setText("Actualizar");
        botonActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonActualizarActionPerformed(evt);
            }
        });

        botonBorrar.setText("Borrar");
        botonBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBorrarActionPerformed(evt);
            }
        });

        cajaCorreo.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        jLabel2.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel2.setText("Dirección:");

        cajaDireccion.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel7))
                        .addGap(24, 24, 24)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cajaNombre, javax.swing.GroupLayout.DEFAULT_SIZE, 222, Short.MAX_VALUE)
                            .addComponent(cajaCodigo))
                        .addGap(113, 113, 113)
                        .addComponent(jLabel5))
                    .addComponent(jLabel6)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(cajaTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(133, 133, 133))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(cajaNit, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 76, Short.MAX_VALUE)
                                .addComponent(jLabel2)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cajaDireccion, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(cajaDpi, javax.swing.GroupLayout.DEFAULT_SIZE, 209, Short.MAX_VALUE)
                        .addComponent(cajaCorreo)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 149, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botonGuardar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonActualizar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonBorrar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cajaNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(cajaDpi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonGuardar))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(cajaCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(cajaTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cajaCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(botonActualizar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(botonBorrar)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(cajaDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cajaNit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tablaDatosJ.setFont(new java.awt.Font("DejaVu Sans", 0, 8)); // NOI18N
        tablaDatosJ.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Codigo", "Telefono", "DPI", "NIT", "Email", "Direccion"
            }
        ));
        tablaDatosJ.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaDatosJMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaDatosJ);

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel8.setFont(new java.awt.Font("DejaVu Sans", 1, 18)); // NOI18N
        jLabel8.setText("INFORMACIÓN SOBRE LOS EMPLEADOS: ");

        jLabel9.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel9.setText("CODIGO:");

        cajaBusqueda.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        botonBuscarID.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        botonBuscarID.setText("Buscar");
        botonBuscarID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBuscarIDActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addGap(18, 18, 18)
                .addComponent(cajaBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(botonBuscarID, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(157, 157, 157))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cajaBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(botonBuscarID))
                .addGap(44, 44, 44))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel10.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel10.setText("BUSQUEDA: ");

        cajaBusquedaDos.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        cajaBusquedaDos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cajaBusquedaDosKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(cajaBusquedaDos, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(271, 271, 271))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cajaBusquedaDos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(0, 0, 0))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 246, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Este método está relacionado con el boton que se encarga de guardar
     * nuevos registros en la base de datos.
     *
     * @param evt
     */
    private void botonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarActionPerformed
        //GUARDAR NUEVOS REGISTROS SOBRE TIENDAS
        String nombre = cajaNombre.getText();
        String telefono = cajaTelefono.getText();
        String nit = cajaNit.getText();
        int dpi = Integer.valueOf(cajaDpi.getText());
        String correo = cajaCorreo.getText();
        String direccion = cajaDireccion.getText();
        String codigo = cajaCodigo.getText();

        try {
            Statement s = dB.miConexion().createStatement();
            s.executeUpdate("INSERT INTO tabla_empleados (descriptivo, nombre, codigo, telefono, dpi, nit, correo, direccion) VALUES ('EMPLEADO', '" + nombre + "' , '" + codigo + "' , '" + telefono + "', '" + dpi + "', '" + nit + "', '" + correo + "', '" + direccion + "')");
            JOptionPane.showMessageDialog(null, "Cambios GUARDADOS");
        } catch (SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "Campos incompletos y/o erroneos ");
        }
        tablaEnPantalla();
    }//GEN-LAST:event_botonGuardarActionPerformed

    /**
     * Este método está relacionado con el textbox que se encarga de buscar los
     * empleados por código.
     *
     * @param evt
     */
    private void botonBuscarIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBuscarIDActionPerformed
        // BUSCAR EMPPLEADO POR ID
        String busqueda = cajaBusqueda.getText();

        try {
            Statement s = dB.miConexion().createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM tabla_empleados WHERE codigo = '" + busqueda + "' ");

            if (rs.next()) {
                cajaNombre.setText(rs.getString("nombre"));
                cajaDireccion.setText(rs.getString("direccion"));
                cajaNit.setText(rs.getString("nit"));
                cajaTelefono.setText(rs.getString("telefono"));
                cajaDpi.setText(rs.getString("dpi"));
                cajaCorreo.setText(rs.getString("correo"));
                cajaCodigo.setText(rs.getString("codigo"));
            }

        } catch (SQLException e) {
            System.out.println(e);
        }
        tablaEnPantalla();
    }//GEN-LAST:event_botonBuscarIDActionPerformed

    /**
     * Este método está relacionado con el boton que permite actualizar los
     * registros existentes en la base de datos.
     *
     * @param evt
     */
    private void botonActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonActualizarActionPerformed
        // ACTUALIZA LOS CAMBIOS HECHOS
        String id = cajaBusqueda.getText();
        String nombre = cajaNombre.getText();
        String telefono = cajaTelefono.getText();
        String nit = cajaNit.getText();
        String dpi = cajaDpi.getText();
        String correo = cajaCorreo.getText();
        String direccion = cajaDireccion.getText();

        try {
            Statement s = dB.miConexion().createStatement();
            s.executeUpdate("UPDATE tabla_empleados SET nombre='" + nombre + "',  telefono='" + telefono + "' , nit= '" + nit + "' , dpi='" + dpi + "' , correo='" + correo + "', direccion='" + direccion + "' WHERE codigo = '" + id + "' ");
            JOptionPane.showMessageDialog(null, "Datos ACTUALIZADOS");
        } catch (HeadlessException | SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "CUIDADO! La operación no pudo completarse");
        }
        tablaEnPantalla();
    }//GEN-LAST:event_botonActualizarActionPerformed

    /**
     * Este método está relacionado con el boton que permite borrar los
     * registros existentes seleccionados.
     *
     * @param evt
     */
    private void botonBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBorrarActionPerformed
        // BORRAR EL REGISTRO DE ALGUN EMPLEADO
        String id = cajaBusqueda.getText();

        try {
            Statement s = dB.miConexion().createStatement();
            s.executeUpdate("DELETE FROM tabla_empleados WHERE codigo = '" + id + "'");
            JOptionPane.showMessageDialog(null, "REGISTRO BORRADO!");
        } catch (HeadlessException | SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "No se pudo completar la acción!");
        }
        tablaEnPantalla();
    }//GEN-LAST:event_botonBorrarActionPerformed
    /**
     * Este método permite que al seleccionar una fila con datos, se rellenen
     * los campos automaticamente
     *
     * @param evt
     */
    private void tablaDatosJMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaDatosJMouseClicked
        //AL HACER CLICK SOBRE LA FILA DESEADA, AUTOMATICAMENTE SE RELLENAN LOS CAMPOS

        int fila = tablaDatosJ.getSelectedRow();

        String id = tablaDatosJ.getValueAt(fila, 1).toString();
        String nombre = tablaDatosJ.getValueAt(fila, 0).toString();
        String codigo = tablaDatosJ.getValueAt(fila, 1).toString();
        String telefono = tablaDatosJ.getValueAt(fila, 2).toString();
        String dpi = tablaDatosJ.getValueAt(fila, 3).toString();
        String nit = tablaDatosJ.getValueAt(fila, 4).toString();
        String correo = tablaDatosJ.getValueAt(fila, 5).toString();
        String direccion = tablaDatosJ.getValueAt(fila, 6).toString();

        cajaBusqueda.setText(id);
        cajaNombre.setText(nombre);
        cajaDireccion.setText(direccion);
        cajaNit.setText(nit);
        cajaTelefono.setText(telefono);
        cajaDpi.setText(dpi);
        cajaCorreo.setText(correo);
        cajaCodigo.setText(codigo);
    }//GEN-LAST:event_tablaDatosJMouseClicked

    /**
     * Este método está relacionado con el textbox que permite la busqueda de
     * empleados según código o nombre
     *
     * @param evt
     */
    private void cajaBusquedaDosKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cajaBusquedaDosKeyReleased
        // BUSCA POR COINCIDENCIA DE NOMBRE O CÓDIGO

        String nombre = cajaBusquedaDos.getText();
        String codigo = cajaBusquedaDos.getText().toString();
        try {
            DefaultTableModel dtm = (DefaultTableModel) tablaDatosJ.getModel();
            dtm.setRowCount(0);
            Statement s = dB.miConexion().createStatement();

            ResultSet rs = s.executeQuery("SELECT * FROM tabla_empleados WHERE nombre LIKE '%" + nombre + "%' ORDER BY nombre  ");

            while (rs.next()) {//inicio del bucle while
                Vector v = new Vector();
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                v.add(rs.getString(6));
                v.add(rs.getString(7));
                v.add(rs.getString(8));

                dtm.addRow(v);

            }//fin del bucle while
        } catch (SQLException e) {
            tablaEnPantalla();
        }

    }//GEN-LAST:event_cajaBusquedaDosKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonActualizar;
    private javax.swing.JButton botonBorrar;
    private javax.swing.JButton botonBuscarID;
    private javax.swing.JButton botonGuardar;
    private javax.swing.JTextField cajaBusqueda;
    private javax.swing.JTextField cajaBusquedaDos;
    private javax.swing.JTextField cajaCodigo;
    private javax.swing.JTextField cajaCorreo;
    private javax.swing.JTextField cajaDireccion;
    private javax.swing.JTextField cajaDpi;
    private javax.swing.JTextField cajaNit;
    private javax.swing.JTextField cajaNombre;
    private javax.swing.JTextField cajaTelefono;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaDatosJ;
    // End of variables declaration//GEN-END:variables
}//FIN DE LA CLASE EMPLEADOS
