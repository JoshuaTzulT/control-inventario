package com.mycompany.inventario.control;

/**
 * Esta clase contiene los elementos de la pagina principal de la Interfaz del
 * usuario
 *
 * @author JoshuaT
 */
public class VentanaPrincipal extends javax.swing.JFrame {//Inicio de la clase VentanaPrincipal

    JpanelLoader jpload = new JpanelLoader();

    /**
     * Constructor de la clase VentanaPrincipal
     */
    public VentanaPrincipal() {//Inicio del constructor 
        initComponents();
        this.setExtendedState(VentanaPrincipal.MAXIMIZED_BOTH);
    }//fin del constructor

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pPrincipalGrupoBotones = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        botonTiendas = new javax.swing.JToggleButton();
        botonRutas = new javax.swing.JToggleButton();
        botonProductos = new javax.swing.JToggleButton();
        botonEmpleados = new javax.swing.JToggleButton();
        botonVentas = new javax.swing.JToggleButton();
        botonPedidos = new javax.swing.JToggleButton();
        botonReportes = new javax.swing.JToggleButton();
        botonClientes = new javax.swing.JToggleButton();
        cargaPanel = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        pPrincipalGrupoBotones.add(botonTiendas);
        botonTiendas.setFont(new java.awt.Font("DejaVu Sans", 1, 14)); // NOI18N
        botonTiendas.setText("TIENDAS");
        botonTiendas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonTiendasActionPerformed(evt);
            }
        });

        pPrincipalGrupoBotones.add(botonRutas);
        botonRutas.setFont(new java.awt.Font("DejaVu Sans", 1, 14)); // NOI18N
        botonRutas.setText("RUTAS");
        botonRutas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRutasActionPerformed(evt);
            }
        });

        pPrincipalGrupoBotones.add(botonProductos);
        botonProductos.setFont(new java.awt.Font("DejaVu Sans", 1, 14)); // NOI18N
        botonProductos.setText("PRODUCTOS");
        botonProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonProductosActionPerformed(evt);
            }
        });

        pPrincipalGrupoBotones.add(botonEmpleados);
        botonEmpleados.setFont(new java.awt.Font("DejaVu Sans", 1, 14)); // NOI18N
        botonEmpleados.setText("EMPLEADOS");
        botonEmpleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEmpleadosActionPerformed(evt);
            }
        });

        pPrincipalGrupoBotones.add(botonVentas);
        botonVentas.setFont(new java.awt.Font("DejaVu Sans", 1, 14)); // NOI18N
        botonVentas.setText("VENTAS");
        botonVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVentasActionPerformed(evt);
            }
        });

        pPrincipalGrupoBotones.add(botonPedidos);
        botonPedidos.setFont(new java.awt.Font("DejaVu Sans", 1, 14)); // NOI18N
        botonPedidos.setText("PEDIDOS");
        botonPedidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonPedidosActionPerformed(evt);
            }
        });

        pPrincipalGrupoBotones.add(botonReportes);
        botonReportes.setFont(new java.awt.Font("DejaVu Sans", 1, 14)); // NOI18N
        botonReportes.setText("REPORTES");

        pPrincipalGrupoBotones.add(botonClientes);
        botonClientes.setFont(new java.awt.Font("DejaVu Sans", 1, 14)); // NOI18N
        botonClientes.setText("CLIENTES");
        botonClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonClientesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botonClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonReportes, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonRutas, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonTiendas, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonEmpleados, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonVentas, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonPedidos, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(68, Short.MAX_VALUE)
                .addComponent(botonTiendas, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(botonRutas, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(botonProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(botonEmpleados, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(botonClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(botonVentas, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(botonPedidos, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(botonReportes, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53))
        );

        cargaPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout cargaPanelLayout = new javax.swing.GroupLayout(cargaPanel);
        cargaPanel.setLayout(cargaPanelLayout);
        cargaPanelLayout.setHorizontalGroup(
            cargaPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 939, Short.MAX_VALUE)
        );
        cargaPanelLayout.setVerticalGroup(
            cargaPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 655, Short.MAX_VALUE)
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 90, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cargaPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cargaPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Este método se encargar de relacionar el boton con de la clase principal
     * con los componenetes graficos de otra clase.
     *
     * @param evt
     */
    private void botonTiendasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonTiendasActionPerformed

        Tiendas tiendas = new Tiendas();
        jpload.jPanelLoader(cargaPanel, tiendas);
    }//GEN-LAST:event_botonTiendasActionPerformed

    /**
     * Este método se encargar de relacionar el boton con de la clase principal
     * con los componenetes graficos de otra clase.
     *
     * @param evt
     */
    private void botonProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonProductosActionPerformed
        Productos productos = new Productos();
        jpload.jPanelLoader(cargaPanel, productos);
    }//GEN-LAST:event_botonProductosActionPerformed

    /**
     * Este método se encargar de relacionar el boton con de la clase principal
     * con los componenetes graficos de otra clase.
     *
     * @param evt
     */
    private void botonEmpleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEmpleadosActionPerformed
        Empleados empleados = new Empleados();
        jpload.jPanelLoader(cargaPanel, empleados);
    }//GEN-LAST:event_botonEmpleadosActionPerformed

    /**
     * Este método se encargar de relacionar el boton con de la clase principal
     * con los componenetes graficos de otra clase.
     *
     * @param evt
     */
    private void botonClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonClientesActionPerformed

        Clientes clientes = new Clientes();
        jpload.jPanelLoader(cargaPanel, clientes);
    }//GEN-LAST:event_botonClientesActionPerformed

    /**
     * Este método se encargar de relacionar el boton con de la clase principal
     * con los componenetes graficos de otra clase.
     *
     * @param evt
     */
    private void botonVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVentasActionPerformed
        Ventas ventas = new Ventas();
        jpload.jPanelLoader(cargaPanel, ventas);
    }//GEN-LAST:event_botonVentasActionPerformed

    /**
     * Este método se encargar de relacionar el boton con de la clase principal
     * con los componenetes graficos de otra clase.
     *
     * @param evt
     */
    private void botonRutasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRutasActionPerformed

        Rutas rutas = new Rutas();
        jpload.jPanelLoader(cargaPanel, rutas);
    }//GEN-LAST:event_botonRutasActionPerformed
    /**
     * Este método se encargar de relacionar el boton con de la clase principal
     * con los componenetes graficos de otra clase.
     *
     * @param evt
     */
    private void botonPedidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonPedidosActionPerformed

        Pedidos pedidos = new Pedidos();
        jpload.jPanelLoader(cargaPanel, pedidos);
    }//GEN-LAST:event_botonPedidosActionPerformed
    /**
     * Este el el método main de toda la aplicaciónm, en la que se cargan tanto
     * excepciones como configuraciones del usuario.
     *
     * @param args
     */
    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> {
            new VentanaPrincipal().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton botonClientes;
    private javax.swing.JToggleButton botonEmpleados;
    private javax.swing.JToggleButton botonPedidos;
    private javax.swing.JToggleButton botonProductos;
    private javax.swing.JToggleButton botonReportes;
    private javax.swing.JToggleButton botonRutas;
    private javax.swing.JToggleButton botonTiendas;
    private javax.swing.JToggleButton botonVentas;
    private javax.swing.JPanel cargaPanel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.ButtonGroup pPrincipalGrupoBotones;
    // End of variables declaration//GEN-END:variables
}//FIN DE LA CLASE  VentanaPrincipal
