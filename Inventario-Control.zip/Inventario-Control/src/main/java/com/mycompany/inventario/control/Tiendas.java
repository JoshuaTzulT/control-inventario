package com.mycompany.inventario.control;

import java.awt.HeadlessException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 * Esta clase define los objetos contenidos en la interfaz grafica,
 * especificamente en la sección de Tiendas.
 *
 * @author JoshuaT
 */
public final class Tiendas extends javax.swing.JPanel {//Inicio de la clase Tiendas

    /**
     * Constructor de la clase Tiendas.
     */
    public Tiendas() {//inicio del constructor
        initComponents();
        tablaEnPantalla();
    }//fin del constructor 

    /**
     * Este método muestra en la GUI, la tabla con los datos contenidos en la
     * base de datos, permitiendo así un interfaz mas amigable con el usuario.
     */
    public void tablaEnPantalla() {//Inicio método tablaEnPantalla

        try {
            DefaultTableModel dtm = (DefaultTableModel) tablaDatosJ.getModel();
            dtm.setRowCount(0);

            Statement s = dB.miConexion().createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM tabla_tiendas ORDER BY nombre, codigo");

            while (rs.next()) {//Inicio bucle while
                Vector v = new Vector();
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                v.add(rs.getString(6));
                v.add(rs.getString(7));
                v.add(rs.getString(8));

                dtm.addRow(v);
            }//final bucle while.
        } catch (SQLException e) {
            System.out.println(e);
        }

    }//Fin método en tablaEnPantalla.

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cajaNombre = new javax.swing.JTextField();
        cajaDireccion = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        cajaCodigo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cajaTelefono = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        cajaTelefonoD = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        cajaHorario = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        botonGuardar = new javax.swing.JButton();
        botonActualizar = new javax.swing.JButton();
        botonBorrar = new javax.swing.JButton();
        cajaCorreo = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaDatosJ = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        cajaBusqueda = new javax.swing.JTextField();
        botonBuscarID = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        cajaBusquedaDos = new javax.swing.JTextField();

        setPreferredSize(new java.awt.Dimension(1179, 782));

        jPanel1.setPreferredSize(new java.awt.Dimension(933, 659));

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel1.setText("Nombre:");

        cajaNombre.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        cajaDireccion.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        jLabel2.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel2.setText("Dirección:");

        cajaCodigo.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        cajaCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaCodigoActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel3.setText("Código:");

        cajaTelefono.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        jLabel4.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel4.setText("Teléfono:");

        cajaTelefonoD.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        jLabel5.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel5.setText("Teléfono 2:");

        cajaHorario.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        jLabel6.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel6.setText("E-mail:");

        jLabel7.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel7.setText("Horario:");

        botonGuardar.setText("Guardar");
        botonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarActionPerformed(evt);
            }
        });

        botonActualizar.setText("Actualizar");
        botonActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonActualizarActionPerformed(evt);
            }
        });

        botonBorrar.setText("Borrar");
        botonBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBorrarActionPerformed(evt);
            }
        });

        cajaCorreo.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cajaDireccion, javax.swing.GroupLayout.DEFAULT_SIZE, 228, Short.MAX_VALUE)
                    .addComponent(cajaCodigo)
                    .addComponent(cajaHorario)
                    .addComponent(cajaNombre))
                .addGap(62, 62, 62)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cajaTelefono, javax.swing.GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE)
                    .addComponent(cajaTelefonoD)
                    .addComponent(cajaCorreo))
                .addGap(77, 77, 77)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botonGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonBorrar, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(botonGuardar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonActualizar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonBorrar))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel1)
                                    .addComponent(cajaNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(cajaTelefonoD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2)
                                    .addComponent(cajaDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel4)
                                .addComponent(cajaTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel6)
                                .addComponent(cajaCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel3)
                                .addComponent(cajaCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(cajaHorario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        tablaDatosJ.setFont(new java.awt.Font("DejaVu Sans", 0, 8)); // NOI18N
        tablaDatosJ.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Direccion", "Codigo", "Telefono", "Telefono 2", "Correo Electronico", "horario"
            }
        ));
        tablaDatosJ.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaDatosJMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaDatosJ);

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel8.setFont(new java.awt.Font("DejaVu Sans", 1, 18)); // NOI18N
        jLabel8.setText("INFORMACIÓN DE LAS TIENDAS");

        jLabel9.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel9.setText("CODIGO:");

        cajaBusqueda.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N

        botonBuscarID.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        botonBuscarID.setText("Buscar");
        botonBuscarID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBuscarIDActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(231, 231, 231)
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(cajaBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(botonBuscarID, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(278, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel8)
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(cajaBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonBuscarID))
                .addGap(0, 0, 0))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel10.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        jLabel10.setText("BUSQUEDA: ");

        cajaBusquedaDos.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        cajaBusquedaDos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cajaBusquedaDosKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(272, 272, 272)
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(cajaBusquedaDos, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cajaBusquedaDos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(0, 0, 0))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 246, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    /**
     * método del boton que permite guardar los cambios hechos en la basa de
     * datos.
     *
     * @param evt
     */
    private void botonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarActionPerformed
        //GUARDAR NUEVOS REGISTROS SOBRE TIENDAS
        String nombre = cajaNombre.getText();
        String direccion = cajaDireccion.getText();
        String codigo = cajaCodigo.getText();
        String telefono = cajaTelefono.getText();
        String telefonoDos = cajaTelefonoD.getText();
        String correo = cajaCorreo.getText();
        String horario = cajaHorario.getText();

        try {
            Statement s = dB.miConexion().createStatement();
            s.executeUpdate("INSERT INTO tabla_tiendas (descriptivo, nombre, direccion, codigo, telefono, telefono_dos, correo, horario) VALUES ('TIENDA','" + nombre + "', '" + direccion + "', '" + codigo + "', '" + telefono + "', '" + telefonoDos + "', '" + correo + "', '" + horario + "')");
            JOptionPane.showMessageDialog(null, "Cambios GUARDADOS");
        } catch (SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "CUIDADO! Datos incorrectos o campos incompletos ");
        }
        tablaEnPantalla();
    }//GEN-LAST:event_botonGuardarActionPerformed

    /**
     * método del textbox que permite buscar por id de la tienda
     *
     * @param evt
     */
    private void botonBuscarIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBuscarIDActionPerformed
        // BUSCAR TIENDA POR ID
        String busqueda = cajaBusqueda.getText();

        try {
            Statement s = dB.miConexion().createStatement();
            ResultSet rs = s.executeQuery(" SELECT * FROM tabla_tiendas WHERE codigo = '" + busqueda + "'  OR nombre = '" + busqueda + "' ");

            if (rs.next()) {
                cajaNombre.setText(rs.getString("nombre"));
                cajaDireccion.setText(rs.getString("direccion"));
                cajaCodigo.setText(rs.getString("codigo"));
                cajaTelefono.setText(rs.getString("telefono"));
                cajaTelefonoD.setText(rs.getString("telefono_dos"));
                cajaCorreo.setText(rs.getString("correo"));
                cajaHorario.setText(rs.getString("horario"));
            }

        } catch (SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "No hay coincidencias");
        }
        tablaEnPantalla();
    }//GEN-LAST:event_botonBuscarIDActionPerformed

    /**
     * método del boton que permite actualizar los datos de la tienda
     *
     * @param evt
     */

    private void botonActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonActualizarActionPerformed
        // ACTUALIZA LOS CAMBIOS HECHOS
        String id = cajaBusqueda.getText();
        String nombre = cajaNombre.getText();
        String direccion = cajaDireccion.getText();
        String codigo = cajaCodigo.getText();
        String telefono = cajaTelefono.getText();
        String telefonoDos = cajaTelefonoD.getText();
        String correo = cajaCorreo.getText();
        String horario = cajaHorario.getText();
        try {
            Statement s = dB.miConexion().createStatement();
            s.executeUpdate("UPDATE tabla_tiendas SET nombre='" + nombre + "', direccion='" + direccion + "', codigo='" + codigo + "', telefono='" + telefono + "', telefono_dos='" + telefonoDos + "', correo='" + correo + "', horario='" + horario + "' WHERE codigo = '" + id + "' ");
            JOptionPane.showMessageDialog(null, "Datos ACTUALIZADOS");
        } catch (HeadlessException | SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "CUIDADO! campos incorrectos o vacios");
        }
        tablaEnPantalla();
    }//GEN-LAST:event_botonActualizarActionPerformed

    /**
     * método que permite borrar los datos de una tienda
     *
     * @param evt
     */
    private void botonBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBorrarActionPerformed
        // BORRAR EL REGISTRO DE ALGUNA TIENDA
        String id = cajaBusqueda.getText();

        try {
            Statement s = dB.miConexion().createStatement();
            s.executeUpdate("DELETE FROM tabla_tiendas WHERE codigo = '" + id + "'");
            JOptionPane.showMessageDialog(null, "REGISTRO BORRADO!");
        } catch (HeadlessException | SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "CUIDADO! La operación no se pudo completar");
        }
        tablaEnPantalla();
    }//GEN-LAST:event_botonBorrarActionPerformed

    /**
     * Este método esta relacionado con la tabla que contiene los datos en la
     * aplicación, al hacer click sobre una fila de datos estos llenan
     * automaticamente los textbox.
     *
     * @param evt
     */
    private void tablaDatosJMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaDatosJMouseClicked
        //AL HACER CLICK SOBRE LA FILA DESEADA, AUTOMATICAMENTE SE RELLENAN LOS CAMPOS
        int fila = tablaDatosJ.getSelectedRow();

        String id = tablaDatosJ.getValueAt(fila, 2).toString();
        String nombre = tablaDatosJ.getValueAt(fila, 0).toString();
        String direccion = tablaDatosJ.getValueAt(fila, 1).toString();
        String codigo = tablaDatosJ.getValueAt(fila, 2).toString();
        String telefono = tablaDatosJ.getValueAt(fila, 3).toString();
        String telefonoDos = tablaDatosJ.getValueAt(fila, 4).toString();
        String correo = tablaDatosJ.getValueAt(fila, 5).toString();
        String horario = tablaDatosJ.getValueAt(fila, 6).toString();

        cajaBusqueda.setText(id);
        cajaNombre.setText(nombre);
        cajaDireccion.setText(direccion);
        cajaCodigo.setText(codigo);
        cajaTelefono.setText(telefono);
        cajaTelefonoD.setText(telefonoDos);
        cajaCorreo.setText(correo);
        cajaHorario.setText(horario);
    }//GEN-LAST:event_tablaDatosJMouseClicked

    /**
     * Este método permite buscar las coincidencias de tiendas, por nombre o
     * codigo
     *
     * @param evt
     */
    private void cajaBusquedaDosKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cajaBusquedaDosKeyReleased
        // BUSCA POR COINCIDENCIA DE NOMBRE

        String codigo = cajaBusquedaDos.getText();
        try {
            DefaultTableModel dtm = (DefaultTableModel) tablaDatosJ.getModel();
            dtm.setRowCount(0);
            Statement s = dB.miConexion().createStatement();

            ResultSet rs = s.executeQuery("SELECT * FROM tabla_tiendas WHERE codigo LIKE '%" + codigo + "%' OR nombre LIKE '%" + codigo + "%' ");

            while (rs.next()) {//inicio bucle while
                Vector v = new Vector();
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                v.add(rs.getString(6));
                v.add(rs.getString(7));
                v.add(rs.getString(8));
                dtm.addRow(v);
            }//fin bucle while.
        } catch (SQLException e) {
            tablaEnPantalla();
        }

    }//GEN-LAST:event_cajaBusquedaDosKeyReleased
    /**
     * @deprecated @param evt
     */
    private void cajaCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaCodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaCodigoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonActualizar;
    private javax.swing.JButton botonBorrar;
    private javax.swing.JButton botonBuscarID;
    private javax.swing.JButton botonGuardar;
    private javax.swing.JTextField cajaBusqueda;
    private javax.swing.JTextField cajaBusquedaDos;
    private javax.swing.JTextField cajaCodigo;
    private javax.swing.JTextField cajaCorreo;
    private javax.swing.JTextField cajaDireccion;
    private javax.swing.JTextField cajaHorario;
    private javax.swing.JTextField cajaNombre;
    private javax.swing.JTextField cajaTelefono;
    private javax.swing.JTextField cajaTelefonoD;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaDatosJ;
    // End of variables declaration//GEN-END:variables
}//fin de la clase Tiendas
