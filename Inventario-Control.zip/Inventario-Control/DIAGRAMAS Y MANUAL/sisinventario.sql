CREATE TABLE IF NOT EXISTS `tabla_tiendas` (
  
`descriptivo` varchar(45) NOT NULL,
  
`nombre` varchar(45) NOT NULL,
  `direccion` varchar(45) NOT NULL,
  
`codigo` varchar(45) NOT NULL,
  `telefono` varchar(45) NOT NULL,
 
 `telefono_dos` varchar(45) DEFAULT NULL,
  `correo` varchar(45) DEFAULT NULL,
 
 `horario` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci




CREATE TABLE IF NOT EXISTS `tiempo_envio` (
  
`descriptivo` varchar(45) NOT NULL,
  
`envid` int NOT NULL AUTO_INCREMENT,
  
`tienda_uno` varchar(45) NOT NULL,
  
`tienda_dos` varchar(45) NOT NULL,
  
`tiempo` int NOT NULL,
  PRIMARY KEY (`envid`),
  
KEY `tienda_uno` (`tienda_uno`),
  
KEY `tienda_dos` (`tienda_dos`),
 
 CONSTRAINT `tiempo_envio_ibfk_1` FOREIGN KEY (`tienda_uno`) REFERENCES `tabla_tiendas` (`codigo`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  
CONSTRAINT `tiempo_envio_ibfk_2` FOREIGN KEY (`tienda_dos`) REFERENCES `tabla_tiendas` (`codigo`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci



CREATE TABLE IF NOT EXISTS `tabla_empleados` (
  
`descriptivo` varchar(45) NOT NULL,
  
`nombre` varchar(45) NOT NULL,
  
`codigo` varchar(45) NOT NULL,
  
`telefono` varchar(45) NOT NULL,
  
`dpi` int NOT NULL,
  
`nit` varchar(45) DEFAULT NULL,
  
`correo` varchar(45) NOT NULL,
  
`direccion` varchar(45) NOT NULL,
  
PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci




CREATE TABLE IF NOT EXISTS `tabla_clientes` (
  
`descriptivo` varchar(45) NOT NULL,
  
`nombre` varchar(45) NOT NULL,
  
`telefono` varchar(45) NOT NULL,
  
`nit` int NOT NULL,
  
`dpi` int DEFAULT NULL,
  
`credito` double DEFAULT NULL,
  
`correo` varchar(45) DEFAULT NULL,
  
`direccion` varchar(45) DEFAULT NULL,
  
PRIMARY KEY (`nit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci





CREATE TABLE IF NOT EXISTS `tabla_productos` (
  
`descriptivo` varchar(45) NOT NULL,
 
`nombre` tinytext NOT NULL,
  
`fabricante` varchar(45) NOT NULL,
  
`codigo` varchar(45) NOT NULL,
  
`cantidad` varchar(45) NOT NULL,
  
`precio` float NOT NULL,
  
`tiendaid` varchar(45) DEFAULT NULL,
  
`descripcion` varchar(45) DEFAULT NULL,
  
`garantia` varchar(45) DEFAULT NULL,
  
`pid` int NOT NULL AUTO_INCREMENT,
  
PRIMARY KEY (`pid`),
  
KEY `cantidad_idx` (`cantidad`),
  
KEY `tiendaid_idx` (`tiendaid`,`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci



CREATE TABLE IF NOT EXISTS `tabla_ventas` (
  
`ventid` int NOT NULL AUTO_INCREMENT,
  
`numero_factura` int NOT NULL,
  
`cliente_id` int NOT NULL,
  
`nombre_cliente` varchar(50) NOT NULL,
  
`cantidad_total` varchar(10) NOT NULL,
  
`pago_total` varchar(10) NOT NULL,
  
`estado` varchar(10) NOT NULL,
  
`saldo` varchar(10) NOT NULL,
  
PRIMARY KEY (`ventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci



CREATE TABLE IF NOT EXISTS `extra` (
  
`exid` int NOT NULL AUTO_INCREMENT,
  
`val` varchar(10) NOT NULL,
  
PRIMARY KEY (`exid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci



CREATE TABLE IF NOT EXISTS `tabla_pedidos` (
  
`descriptivo` int NOT NULL,
  
`codigo_pedido` varchar(45) NOT NULL,
  
`tienda_uno` varchar(45) NOT NULL,
  
`tienda_dos` varchar(45) NOT NULL,
  
`fecha` varchar(45) NOT NULL,
  
`cliente` varchar(45) NOT NULL,
  
`articulo` varchar(45) NOT NULL,
  
`cantidad` varchar(45) NOT NULL,
  
`total` varchar(45) NOT NULL,
  
`anticipo` varchar(45) NOT NULL,
  
PRIMARY KEY (`descriptivo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci



























